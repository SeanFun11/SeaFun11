# Project Scope Statement: Personal Webpage

**Project Manager:** Sean Funches

## Project Purpose

The purpose of this project is to build a personal webpage using HTML and CSS that introduces me, communicates my professional interests, and serves as a foundation for developing stronger technical and project management skills. This project marks my first step in becoming confident using GitHub and web development tools, skills I intend to carry into my future career in project management, particularly within the construction field.

## Description

This project involves creating a single-page personal website that includes my name, a subheading describing my professional interests, two or more paragraphs describing my goals for this course and my career, a list of my hobbies and interests, and a link to my GitHub profile. The page will be styled with a custom CSS stylesheet to apply colors, fonts, spacing, and layout elements such as a background color, distinct heading and paragraph styling, and a bordered content box. The site will be built and managed using GitHub to practice creating, organizing, and version-controlling project files.

## Desired Results

By the end of this project, I want to have:
- A working `index.html` file that is well-structured, valid, and contains all required elements (title, headings, paragraphs, list, and hyperlink).
- A linked `style.css` file that visibly changes the appearance of the page, including background color, heading and paragraph fonts/colors, and spacing around content.
- A clearer understanding of how HTML and CSS work together to build and style a webpage.
- Increased comfort using GitHub to create, organize, and manage my project files.
- A personal webpage that reflects my goals of becoming a project manager and highlights my interests and background.

## Exclusions

This project does not include:
- Advanced or highly polished visual design — the focus is on planning and structure, not aesthetics.
- Interactive features such as JavaScript functionality, forms, or animations.
- Responsive design for multiple screen sizes beyond the basic viewport meta tag.
- Backend functionality, databases, or server-side processing.
- Content unrelated to my personal introduction, course goals, career goals, and hobbies (e.g., a full portfolio or blog).
